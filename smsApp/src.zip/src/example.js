import React, { Component } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';

import {
  MenuProvider,
  Menu,
  MenuTrigger,
  MenuOptions,
  MenuOption,
} from 'react-native-popup-menu';



export default class Example extends Component {
constructor(props){
super(props);
this.state = {
    checked:true,
    completion:this.props.completion
};
}
  render() {
    return (
<View style={{paddingTop:30}}>
<Text>
{this.state.completion}
</Text>
</View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
  },
});