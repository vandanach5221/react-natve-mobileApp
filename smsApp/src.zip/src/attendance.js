import React from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, BackHandler, ActivityIndicator,
         Dimensions, } from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
  listenOrientationChange as loc,
  removeOrientationListener as rol
} from 'react-native-responsive-screen';
import Icon from 'react-native-vector-icons/Ionicons';
import CheckBox from 'react-native-check-box';

let {width, height} = Dimensions.get('window');

export default class Attendance extends React.Component {
constructor(props){
super(props);
this.state = {
    scheduleList:[
                 {
                         "name":"arun",
                         "isChecked":true,
                 },
                 {
                          "name":"atul",
                          "isChecked":true,
                  },
                {
                         "name":"aaryan",
                         "isChecked":false,
                 },
                 {
                          "name":"anuj",
                          "isChecked":false,
                  },
                  {
                           "name":"abhishekh",
                           "isChecked":true,
                   },
               {
                        "name":"risabh",
                        "isChecked":true,
                },
                 ],
    isChecked:false,
};
}
componentDidMount()
{
this.scheduleList();
}

  selectItem = data => {
//alert(data.item.completion);

 };
 changePassword(){
       Actions.changepassword();
  }

//removeEverything = async () => {
//   try {
//     await AsyncStorage.clear()
//      this.refs.toast.show(<View><Text style = {{color: 'green',fontSize: 18,}}>Logged Out Successfully!</Text></View>);
//   } catch (e) {
//     this.refs.toast.show('Failed to clear the async storage.')
//   }
// }

  logout = () => {
//     this.removeEverything();
     Actions.login();
   };

  scheduleList = () => {
                         this.state.scheduleList = this.state.scheduleList.map(item =>
                             {
                                item.isSelect = false;
                                return item;
                                        });
                            };



  renderItem = data =>
         <View style={{flexDirection:"row"}}>
<CheckBox
    style={{flex: 1, padding: 10}}
    onClick={()=>{
      this.setState({
          isChecked:!this.state.isChecked
      })
    }}
    isChecked={this.state.isChecked}
    rightText={data.item.name}
/>
         </View>

render()
{
return(
<View style={{flex:1,marginTop:hp("4%")}}>
   <View style={{height:height/15,backgroundColor:"#FFE4C4"}}>
    </View>
       <TouchableOpacity style = {styles.logoutButton} onPress = {this.logout}>
              <Icon color="white" size={30} name={'ios-power'}/>
       </TouchableOpacity>
       <TouchableOpacity style = {styles.forgotButton} onPress = {this.changePassword}>
              <Icon color="white" size={30} name={'ios-lock'}/>
       </TouchableOpacity>
    <View style={{flexDirection:"row",justifyContent:"space-between",padding:10}}>
        <Text style={{fontSize:17}}>Date: 23-Mar</Text>
        <Text style={{fontSize:17}}>Class: X - B</Text>
    </View>
    <View style={{flexDirection:"row",paddingHorizontal:15,alignSelf:"center",width:width/1.7}}>
    <CheckBox
        style={{flex: 1, padding: 10,fontSize:17}}
        onClick={()=>{
          this.setState({
              isChecked1:!this.state.isChecked1
          })
        }}
        isChecked={this.state.isChecked1}
        rightText={"Attendence"}
    />
    <View style={{flexDirection:"column"}}>
        <Text>Absent: 1</Text>
        <Text>Leave:  1</Text>
    </View>
    </View>
    <FlatList
       data={this.state.scheduleList}
       renderItem={item => this.renderItem(item)}
     />

</View>
)
}
}

const styles = StyleSheet.create({
    list: {
        width:width,
        height:height/8,
        alignSelf:"center",
        padding:"2%",
        borderWidth: 0.4,
        backgroundColor: 'white',
        borderTopColor: '#000000',
        },
     logoutButton: {
                  backgroundColor: 'red',
                  position: 'absolute',
                  borderRadius:30,
                  zIndex: 1000,
                  width:wp("9%"),
                  height:hp("5%"),
                  alignItems:"center",
                  justifyContent:"center",
                  right: 8,
                  top: 6,
                  },
                  forgotButton: {
                   backgroundColor: 'green',
                  width:wp("9%"),
                  borderRadius:30,
                     height:hp("5%"),
                     alignItems:"center",
                     justifyContent:"center",
                    position: 'absolute',
                    zIndex: 1000,
                    right: 55,
                    top: 6,
                  },
});