import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  StatusBar,
  TextInput,
  Button,
  TouchableOpacity,
  Linking,
  ImageBackground,
  Alert,
  ScrollView,
  AsyncStorage,
  BackHandler,
  Dimensions,
  Animated,
  Image,
  KeyboardAvoidingView
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
  listenOrientationChange as loc,
  removeOrientationListener as rol
} from 'react-native-responsive-screen';
import Toast, {DURATION} from 'react-native-easy-toast';
let {width, height} = Dimensions.get('window');
import axios from  'axios';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scrollview';
import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/Ionicons';
var querystring = require('query-string');
//var httpURL = 'http://192.168.1.7:8081/cs';
//var httpURL = 'http://35.202.143.172:8080/cs';
var httpURL = 'http://cs.kmsgtech.com:12106/cs';

const STORAGE_KEY = 'EMAIL';
const STORAGE_USER_KEY = 'USERID';

export default class Login extends Component {
  constructor(props) {
    super(props);
        this._didFocusSubscription = props.navigation.addListener(
              'didFocus',
              payload =>
                BackHandler.addEventListener(
                  'hardwareBackPress',
                  this.onBackButtonPressAndroid
                )
            );
    this.state = {
      showPass: true,
      press : false,
      customerLogin: '',
      email : '',
      asyncEmail : '',
      verify: {},
      buyerId: '',
      customerId:'',
      pass:'',
    }
  }

  componentDidMount() {
      this._willBlurSubscription = this.props.navigation.addListener(
              'willBlur',
              payload =>
                BackHandler.removeEventListener(
                  'hardwareBackPress',
                  this.onBackButtonPressAndroid
                )
            );
  }

 onBackButtonPressAndroid = () => {
   BackHandler.exitApp();
  };

  componentWillUnmount() {
    this._didFocusSubscription && this._didFocusSubscription.remove();
    this._willBlurSubscription && this._willBlurSubscription.remove();
  }

//   isValid() {
//       const { email, pass } = this.state;
//      let valid = false;
//
//      if (email.length > 0 && pass.length > 0) {
//        valid = true;
//      }
//
//      if (email.length === 0) {
//        this.setState({ error: 'You must Username' });
//      } else if (pass.length === 0) {
//        this.setState({ error: 'You must enter Password' });
//      }
//      return valid;
//    }
//
//    async saveLoginData(asyncEmail,buyerId)
//    {
//        try {
//                 await AsyncStorage.setItem(STORAGE_KEY, asyncEmail);
//                 await AsyncStorage.setItem(STORAGE_USER_KEY, buyerId+"");
//               } catch (e) {
//                 this.refs.toast.show('Failed to save email and buyerId.'+e)
//               }
//    }
//
//   onSubmitEditing = () => {
//             const onSave = this.saveLoginData
//             const { asyncEmail } = this.state
//
//
//             if (!asyncEmail) return
//
//             onSave(asyncEmail,this.state.buyerId)
//            // alert(this.state.buyerId)
//             this.setState({ asyncEmail: '' })
//         }

signIn = () => {
//   var customer = {
//                       "email":this.state.email,
//                      	"password" :this.state.pass,
//                      	};
//          const apiBaseUrl = httpURL+'/b/l/login';
//                  axios.post(apiBaseUrl,
//   			      querystring.stringify({'loginInfo':JSON.stringify(customer)}))
//   		          .then((response)=>{
//   		    if(response.data.SvcStatus == 'Success'){
//   		          this.refs.toast.show(<View><Text style={styles.successToast}>{response.data.SvcMsg}</Text></View>);
//   		          this.setState({ asyncEmail:this.state.email,buyerId:response.data.buyerInfo.buyerId })
//   		          //alert(this.state.buyerId)
//                  this.onSubmitEditing();
                  Actions.schedule();
//                       }
//                  else
//             {
//               this.refs.toast.show(response.data.SvcMsg);
//              }
//                }).catch((e)=>{
//                     alert("Service failed");
//                });
                }

                     showPass=()=>{
                        if(this.state.press == false){
                          this.setState({showPass: false, press: true})
                        }else{
                          this.setState({showPass: true, press: false})
                        }
                      }

//         forgotPassword(){
//
//              var customer = {
//                         "email":this.state.email,
//                         "password" :this.state.pass,
//                            };
//               if(customer.email == ""){
//                 this.refs.toast.show("Please Enter Email");
//               }
//               else{
//                   const apiBaseUrl =httpURL+'/b/l/forgot_password';
//                   axios.post(apiBaseUrl,
//                     querystring.stringify({'loginInfo':JSON.stringify(customer)}))
//                    .then((response)=>{
//                     if(response.data.SvcStatus == 'Success'){
//                           this.refs.toast.show(<View><Text style = {{color: 'green',fontSize: 18,}}>{response.data.SvcMsg}</Text></View>);
//                       }
//                       else{
//                            this.refs.toast.show(response.data.SvcMsg);
//                       }
//                       }).catch((error)=>{
//                          this.refs.toast.show('Service failed: '+error);
//                       });
//               }
//         }


render(){
   return (
       <ImageBackground
      source={require('../images/splash4.jpg')}
      style={styles.container1}>
        <View style={{flex:1,flexDirection:"row",alignItems:"center",alignSelf:"center",borderRadius:40}}>
           <View style={styles.boxStyle} opacity={0.90}>
           <KeyboardAvoidingView  style={styles.containerStyle} behavior="padding" enabled>
             <Image source={require('../images/kmsglogo.png')}  style={styles.logoImg} opacity={1} />
             <Text style={styles.buyerLogin} >Teacher Login</Text>
                <View style={styles.container}  opacity={1}>
                     <TextInput style={styles.inputBox1}
                       placeholder="Username"
                       keyboardType="email-address"
                       placeholderTextColor="grey"
                       backgroundColor='white'
                       onChangeText={(text) => this.setState({email:text})}
                      />
                    <View style={styles.InputContainer}>
                         <TextInput style={styles.inputBox}
                           placeholder="Password"
                           backgroundColor='white'
                           secureTextEntry={this.state.showPass}
                           placeholderTextColor="grey"
                           onChangeText={(text) => this.setState({pass:text})}
                          />
                          <TouchableOpacity style={styles.btnEye}
                              onPress={this.showPass.bind(this)}>
                            <Icon name={this.state.showPass==false ? 'ios-eye' : 'ios-eye-off'} size={22} color={'#000'}
                            />
                          </TouchableOpacity>
                     </View>

                      <TouchableOpacity onPress={() => this.forgotPassword()} style ={styles.forgotPassword} >
                            <Text style ={styles.forgotPass}>Forgot Password</Text>
                        </TouchableOpacity>

                      <TouchableOpacity onPress={() => this.signIn()}  style={styles.button} >
                        <Text style={styles.loginButton} > Login </Text>
                      </TouchableOpacity>
                </View>
           </KeyboardAvoidingView>
           </View>
             <Toast
                ref="toast"
                position='bottom'
                positionValue={100}
                fadeInDuration={750}
                fadeOutDuration={1000}
                opacity={0.8}
                textStyle={{color:'red',fontSize: 18,}}
            />
       </View>
       </ImageBackground>
   );
}

}

const styles = StyleSheet.create({
    containerStyle:{
    height:hp("60%"),
    width:wp("80%"),
    justifyContent: 'center',
    flexDirection: 'column',
    alignItems: 'center',
    borderRadius:40,
    borderBottomWidth:5,
    borderTopWidth:5,
    borderLeftWidth:5,
    borderRightWidth:5,
    borderColor:"#F36F22"
    },
  boxStyle:{
    height:hp("60%"),
    width:wp("80%"),
    backgroundColor:"white",
    alignSelf:"center",
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius:40,
  },
  btnEye: {
    position: 'absolute',
    top: 25,
    right: 15,
  },
  container: {
    padding: '1%',
    opacity: 0.8,
    borderRadius: 15,
  },
   logoImg : {
      width: wp('22%'),
      height:hp("11%"),
      resizeMode: 'stretch',
      borderRadius:wp("2%"),
      marginBottom:hp("1%"),
    },
  container1: {
    width: wp("100%"),
    height: hp("100%"),
    resizeMode: 'contain',
     backgroundColor: '#C0C0C0',
  },
  button: {
    backgroundColor:'#F36F22',
    padding: wp("3%"),
    marginTop: hp("2%"),
    marginBottom: hp("2%"),
    borderRadius: wp("1%"),
    alignSelf:"center",
    width:wp("20%"),
    textAlign: 'center',
  },
    button1: {
        marginTop: 30,
        alignSelf: 'flex-start',
     },
  inputBox: {
      width: wp('70%'),
      borderRadius: wp("5%"),
      alignItems: 'center',
      fontSize:16,
      padding: wp("2%"),
      color:'black',
      marginVertical: wp("2%"),
      borderWidth:2,
      borderColor:"#DCDCDC"
    },
      inputBox1: {
          width: wp('70%'),
          marginTop: hp("4%"),
          borderRadius: wp("5%"),
          alignItems: 'center',
          fontSize:16,
          padding: wp("2%"),
          color:'black',
          marginVertical: wp("2%"),
          borderWidth:2,
          borderColor:"#DCDCDC"
        },
    forgotPassword: {
    alignSelf: 'flex-end',
    },

    forgotPass: {
        alignSelf:'flex-end',
        paddingRight: 20,
        fontSize: 16,
        fontWeight: 'bold',
        color: "#F36F22",
    },
    loginButton: {
        textAlign: 'center',
        fontSize: 16,
        color: '#fff',
        fontWeight: 'bold',
    },
    buyerLogin:{
        fontSize:18,
        color:"#F36F22",
        fontWeight:"bold"
    },

});



