import React from 'react';
import { Actions } from 'react-native-router-flux';
import {BackHandler,StyleSheet,Image,StatusBar, View, Dimensions, Animated, TouchableOpacity, Text,AsyncStorage,
ImageBackground} from 'react-native';
import ProgressCircle from 'react-native-progress-circle';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
  listenOrientationChange as loc,
  removeOrientationListener as rol
} from 'react-native-responsive-screen';
let {width, height} = Dimensions.get('window');
const STORAGE_KEY = 'EMAIL';
const STORAGE_USER_KEY = 'USERID';
var interval = "";

export default class Splash extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
        percentage:0,
    }
  }
	componentDidMount(){
		 interval = setInterval(() => {
    	        if(this.state.percentage < 100)
    	        {
    	            if(this.state.percentage == 98)
    	            {
    	                  this.setState({
                                   percentage:100,
                               });
    	            }else
    	            {
                        this.setState({
                            percentage:this.state.percentage + 7,
                        });
                    }
    	        }
    	        else
    	        {
    	              clearInterval(interval);
    	        }
          }, 100);
            this.timeoutHandle = setTimeout(()=>{
              Actions.schedule();
            }, 2000);
//	 interval = setInterval(() => {
//	        if(this.state.percentage < 100)
//	        {
//	            if(this.state.percentage == 98)
//	            {
//	                  this.setState({
//                               percentage:100,
//                           });
//	            }else
//	            {
//                    this.setState({
//                        percentage:this.state.percentage + 7,
//                    });
//                }
//	        }
//	        else
//	        {
//	              clearInterval(interval);
//
//	          //    this.retrieveData();
//	        }
//      }, 100);
//        this.timeoutHandle = setTimeout(()=>{
//          Actions.login();
//        }, 2000);
//		 this.retrieveData();
	}
//
//	retrieveData = async () => {
//
//                try {
//                  const emailId = await AsyncStorage.getItem(STORAGE_KEY)
//                  const buyerId = await AsyncStorage.getItem(STORAGE_USER_KEY)
//                  if (emailId !== null && buyerId !== null) {
//
//                     this.timeoutHandle = setTimeout(()=>{
//                         // alert(buyerId)
//                          Actions.schedule();
//                        }, 500);
//                  }
//                  else
//                  {
//                    this.timeoutHandle = setTimeout(()=>{
//                              Actions.login();
//                    		}, 500);
//                  }
//                } catch (e) {
//                  alert('Failed to load name.')
//                }
//              }

	componentWillUnmount(){

		 //clearTimeout(this.timeoutHandle);
		 StatusBar.setHidden(true);

	}
	componentWillmount(){
		 StatusBar.setHidden(true);

	}



  render() {
	return (
	   <ImageBackground opacity={0.8}
          source={require('../images/splash.jpg')}
          style={styles.container1}>
            <View style= {styles.textWrap}>
            </View>
            <ProgressCircle
            percent={this.state.percentage}
            radius={40}
            borderWidth={8}
            color="#FA8072"
            shadowColor="#999"
            bgColor="#FFF8DC"
    >
        <Text style={{ fontSize: 19 }}>{this.state.percentage+'%'}</Text>
    </ProgressCircle>
            <View style= {styles.copyrightWrap}>
                <Text style = {styles.copyrights}> Powered By KMSG Technologies </Text>
            </View>
       </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    justifyContent: 'center',
    paddingLeft: 10,
    paddingRight: 10,
  },
  splashImg : {
     alignItems:"center",
     alignSelf:"center",
     width: '50%',
      height:"30%",
      resizeMode: 'contain',
  },
    logoImg : {
       width: wp('22%'),
       height:wp("22%"),
       resizeMode: 'stretch',
       borderRadius:wp("11%"),
       marginBottom:hp("1%"),
       flexDirection:"column"
     },
    container1: {
      width: "100%",
      height: "100%",
      resizeMode: 'contain',
       backgroundColor: '#C0C0C0',
       alignItems:"center",
    },
  textWrap: {
   alignSelf: "center",
   alignItems:"center",
   justifyContent: 'center',
   flex:1,flexDirection:"row",
         paddingBottom:10,
  },
   innerTextWrap: {
     alignSelf: "center",
     alignItems:"center",
     justifyContent: 'center',
     flex:1,flexDirection:"column",
    },
  splashText: {
  width: '60%',
  alignSelf: 'center',
  fontWeight: 'bold',
  textAlign : 'center',
  fontSize: 35,
  color: "white",
  },
      copyrightWrap: {
          position: 'relative',
          bottom: 0,
          alignSelf:"flex-end",
          fontSize:10,
          backgroundColor:"transparent"
      },
      copyrights:{
      color:"white",
      fontSize:9,
      },
});