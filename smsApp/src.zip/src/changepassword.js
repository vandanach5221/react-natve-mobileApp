import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  TextInput,
  Button,
  View,
  AsyncStorage,
  Alert,
  TouchableOpacity
} from 'react-native';
import axios from  'axios';
import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/Ionicons';
import Toast, {DURATION} from 'react-native-easy-toast';

//var httpURL = 'http://192.168.1.7:8081/cs';
//var httpURL = 'http://35.202.143.172:8080/cs';
//var httpURL = 'http://cs.kmsgtech.com:12106/cs';
//const STORAGE_KEY = 'EMAIL'
var pass='';
var email='';

export default class ChangePassword extends Component {

  constructor(props) {
    super(props);
    this.state = {
      pass:'',
      newpass:'',
      cnfpass:'',
      phone: '',
      email: '',
      showPass: true,
      showPass1: true,
    }
  }

 componentDidMount() {
    this.retrieveData()
  }

retrieveData = async () => {
    try {
      const email = await AsyncStorage.getItem(STORAGE_KEY)
      if (email !== null) {
        this.setState({ email })
      }
    } catch (e) {
      this.refs.toast.show('Failed to load name.')
    }
  }

//  submit=()=>{
//        var customer = {
//             "email":this.state.email,
//             "oldPassword" :this.state.pass,
//             "newPassword" :this.state.newpass
//                };
//          pass=this.state.pass;
//          email=this.state.email;
//           var newpass=this.state.newpass;
//           var cnfpass=this.state.cnfpass;
//            if (pass.length != 0 && newpass.length != 0 && cnfpass.length != 0){
//                if (this.state.newpass == this.state.cnfpass){
//                       var querystring = require('query-string');
//                       const apiBaseUrl =httpURL+'/b/l/change_password';
//                       axios.post(apiBaseUrl,
//                        querystring.stringify({'changePassword':JSON.stringify(customer)}))
//                       .then((response)=>{
//
//                     if(response.data.SvcStatus == 'Success'){
//                               this.refs.toast.show(<View><Text style = {{color: 'green',fontSize: 18,}}>{response.data.SvcMsg}</Text></View>);
//                              this.removeEverything();
//                              Actions.login();
//                               }
//                               else{
//                                   this.refs.toast.show(response.data.SvcMsg);
//                               }
//                               }).catch((error)=>{
//                                 this.refs.toast.show('Service failed: '+error);
//                               });
//                      }
//                       else{
//                          this.refs.toast.show('Your Password Does Not Match');
//                          }
//                }
//                 else{
//                    this.refs.toast.show('Please Fill All The Fields');
//                }
//
//            }


  showPass=()=>{
            if(this.state.press == false){
              this.setState({showPass: false, press: true})
            }else{
              this.setState({showPass: true, press: false})
            }
          }
       showPass1=()=>{
                  if(this.state.press == false){
                    this.setState({showPass1: false, press: true})
                  }else{
                    this.setState({showPass1: true, press: false})
                  }
                }

cancel = () => {
    Actions.schedule();
}

 removeEverything = async () => {
    try {
      await AsyncStorage.clear()

    } catch (e) {
      this.refs.toast.show('Failed to clear the async storage.')
    }
  }
  render() {
   const { phone, name } = this.state
    return (
      <View style={styles.container}>
            <Text style={styles.changePass}> Change Your Password </Text>
           <TextInput
           style={styles.formInput}
           placeholder="Enter your Old Password"
           value={this.state.pass}
           onChangeText={(text) => this.setState({pass:text})}
            />
            <View style={styles.InputContainer}>
               <TextInput
               style={styles.formInput}
               placeholder="Enter your New Password"
               value={this.state.newpass}
               onChangeText={(text) => this.setState({newpass:text})}
                secureTextEntry={this.state.showPass}
               />
               <TouchableOpacity style={styles.btnEye}
                     onPress={this.showPass.bind(this)}>
                   <Icon name={this.state.showPass==false ? 'ios-eye' : 'ios-eye-off'} size={26} color={'#000'}
                   />
                 </TouchableOpacity>
            </View>
            <View style={styles.InputContainer}>
                   <TextInput
                   style={styles.formInput}
                   placeholder="Re-Enter Your New Password"
                   value={this.state.cnfpass}
                   onChangeText={(text) => this.setState({cnfpass:text})}
                   secureTextEntry={this.state.showPass1}
                   />
                    <TouchableOpacity style={styles.btnEye}
                        onPress={this.showPass1.bind(this)}>
                      <Icon name={this.state.showPass1==false ? 'ios-eye' : 'ios-eye-off'} size={26} color={'#000'}
                      />
                    </TouchableOpacity>
            </View>

                   <View style={styles.buttonWrap}>
                        <TouchableOpacity
                         style={styles.formButton}
                         onPress={this.submit}
                         >
                        <Text style={styles.buttonText}>Submit </Text>
                        </TouchableOpacity>

                       <TouchableOpacity
                          style={styles.formButton1}
                          onPress={this.cancel}
                       >
                      <Text style={styles.buttonText1}> Cancel </Text>
                       </TouchableOpacity>

                   </View>
             <Toast
                ref="toast"
                position='bottom'
                positionValue={100}
                fadeInDuration={750}
                fadeOutDuration={1000}
                opacity={0.8}
                textStyle={{color:'red',fontSize: 18,}}
            />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 30,
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: 'white',
    justifyContent: 'center',
  },
   btnEye: {
      position: 'absolute',
      top: 10,
      right: 15,
    },
  welcome: {
    fontSize: 20,
    marginBottom:10,

  },
  changePass: {
  fontSize: 22,
  color: 'black',
  fontWeight: 'bold',
  marginBottom: 15,
  textAlign: 'center',
  },
  formInput: {
    paddingLeft: 15,
    marginBottom:10,
    height: 50,
    borderWidth: 1,
    color:'black',
    borderRadius: 25,
    fontSize: 16,
    backgroundColor: 'white',
  },
  formButton: {
    borderWidth: 1,
    borderColor: "#555555",
    borderRadius: 25,
    height: 50,
    backgroundColor: '#FF7F50',
    marginTop: 10,
    justifyContent: 'center',
  },
   formButton1: {
      borderWidth: 1,
      borderColor: "#555555",
      borderRadius: 25,
      height: 50,
      backgroundColor: '#787878',
      marginTop: 10,
      justifyContent: 'center',
    },
  buttonWrap: {
  display: 'flex',
  justifyContent: 'space-around',
  },
  buttonText: {
  fontSize: 16,
  fontWeight: 'bold',
  textAlign: 'center',
  },
   buttonText1: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#fff'
    },

  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
    marginTop: 5,
  },
});