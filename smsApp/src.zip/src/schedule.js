import React from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, BackHandler, ActivityIndicator,
         Dimensions, } from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
  listenOrientationChange as loc,
  removeOrientationListener as rol
} from 'react-native-responsive-screen';
import Icon from 'react-native-vector-icons/Ionicons';
import Dialog, { DialogFooter, DialogButton, DialogTitle, SlideAnimation, DialogContent } from 'react-native-popup-dialog';

let {width, height} = Dimensions.get('window');

export default class Schedule extends React.Component {
constructor(props){
super(props);
this.state = {
    scheduleList:[
                 {
                         "time":"09:00 AM",
                         "subject":"Science",
                         "topic":"Heat-Energy",
                         "class":"IX",
                         "section":"C",
                         "completion":"100%"
                 },
                 {
                         "time":"10:00 AM",
                         "subject":"Science",
                         "topic":"Sound-Energy",
                         "class":"XI",
                         "section":"B",
                         "completion":"40%"
                 },
                 {
                         "time":"11:00 AM",
                         "subject":"Math",
                         "topic":"Triangle",
                         "class":"X",
                         "section":"B",
                         "completion":"60%"
                 },
                 {
                         "time":"12:00 PM",
                         "subject":"Math",
                         "topic":"Height and distances",
                         "class":"VII",
                         "section":"D",
                         "completion":"70%"
                 },
                 {
                         "time":"01:00 AM",
                         "subject":"Social Science",
                         "topic":"Demographics",
                         "class":"III",
                         "section":"B",
                         "completion":"100%"
                 },
                 {
                         "time":"02:00 PM",
                         "subject":"English",
                         "topic":"Noun",
                         "class":"II",
                         "section":"A",
                         "completion":"10%"
                 },
                 ],
    visible:false,
    popUpTime:'',
    popUpCompletionPercentage:'',
};
}
componentDidMount()
{
this.scheduleList();
}

  selectItem = data => {
//alert(data.item.time);
this.setState({ visible: true })
this.setState({popUpTime:data.item.time})
this.setState({popUpCompletionPercentage:data.item.completion})
  };

  scheduleList = () => {
                         this.state.scheduleList = this.state.scheduleList.map(item =>
                             {
                                item.isSelect = false;
                                return item;
                                        });
                            };
 changePassword(){
       Actions.changepassword();
  }

//removeEverything = async () => {
//   try {
//     await AsyncStorage.clear()
//      this.refs.toast.show(<View><Text style = {{color: 'green',fontSize: 18,}}>Logged Out Successfully!</Text></View>);
//   } catch (e) {
//     this.refs.toast.show('Failed to clear the async storage.')
//   }
// }

  logout = () => {
//     this.removeEverything();
     Actions.login();
   };


  renderItem = data =>
         <TouchableOpacity style={styles.list}
           onPress={() => this.selectItem(data)}
           >
           <View style={styles.listView}>
                <View styles={styles.timingAndTopic}>
                    <Text style={styles.timeText}>{data.item.time}</Text>
                    <Text style={styles.topicText}>{data.item.subject + '-' + data.item.topic}</Text>
                </View>
                <View style={styles.classAndCompletion}>
                    <Text style={styles.classText}>{data.item.class + '-' + data.item.section}</Text>
                    <Text style={styles.completion}>{(data.item.completion == "100%") ?
                    <Icon color="#8B0000" style={{color:"green",marginRight:10,}} size={30} name={'ios-checkmark-circle'}/> :
                     data.item.completion}
                    </Text>
                </View>

           </View>
        </TouchableOpacity>

render()
{
return(
<View style={{flex:1,marginTop:hp("4%")}}>
    <View style={{height:height/15,backgroundColor:"#FFE4C4"}}>
    </View>
       <TouchableOpacity style = {styles.logoutButton} onPress = {this.logout}>
              <Icon color="white" size={30} name={'ios-power'}/>
       </TouchableOpacity>
       <TouchableOpacity style = {styles.forgotButton} onPress = {this.changePassword}>
              <Icon color="white" size={30} name={'ios-lock'}/>
       </TouchableOpacity>
    <FlatList
       data={this.state.scheduleList}
       renderItem={item => this.renderItem(item)}
     />
        <Dialog
                         width={width/1.5}
                         height={height/3.3}
                         visible={this.state.visible}
                         dialogTitle={<DialogTitle title= {this.state.popUpTime} />}
                         footer={
                           <DialogFooter>
                             <DialogButton
                               text="CANCEL"
                               onPress={() => {
                                 this.setState({visible:false});
                                 }}
                             />
                             <DialogButton
                               text="OK"
                               onPress={() => {
                                 this.setState({visible:false});
                                 }}
                             />
                           </DialogFooter>
                          }
                         onTouchOutside={() => {
                           this.setState({visible:false});
                           }}
                         dialogAnimation={new SlideAnimation({
                           slideFrom: 'bottom',
                         })}
                       >
                         <DialogContent>
                           {
                           <View style = {{flexDirection:"row"}}>
                             <View style={{flexDirection:"column",width:width/5}}>
                                 <Text style={{marginBottom:6}}>%Complete</Text>
                                 <Text>Remarks</Text>
                             </View>
                             <View style={{flexDirection:"column",width:width/3}}>
                                 <Text style={{marginBottom:6}}>{this.state.popUpCompletionPercentage}</Text>
                                 <Text style={{width:width/2.8,height:height/14}}>Any Body Can Dance</Text>
                             </View>
                           </View>
                           }
                         </DialogContent>
                </Dialog>
</View>
)
}
}

const styles = StyleSheet.create({
    list: {
        width:width,
        height:height/8,
        alignSelf:"center",
        padding:"2%",
        borderWidth: 0.4,
        backgroundColor: 'white',
        borderTopColor: '#000000',
        },
     listView:{
        justifyContent:"space-between",
        flexDirection:"row",
  //      backgroundColor:"red",
        },
     classAndCompletion:{
        flexDirection:"row",
        width:width/4,
        justifyContent:"space-between",
     //   backgroundColor:"red"
        },
     timingAndTopic:{
        flexDirection:"row",
        width:width/2,
        justifyContent:"space-between",
     //   backgroundColor:"red"
        },
     timeText:{
        fontSize:22,
        fontWeight:"bold",
        height:height/15,
        },
     topicText:{
        fontSize:16,
        },
     classText:{
        fontSize:16,
        fontWeight:"bold",
        },
     completion:{
         fontSize:16,
         fontWeight:"bold",
         },
       logoutButton: {
              backgroundColor: 'red',
              position: 'absolute',
              borderRadius:30,
              zIndex: 1000,
              width:wp("9%"),
              height:hp("5%"),
              alignItems:"center",
              justifyContent:"center",
              right: 8,
              top: 6,
              },
              forgotButton: {
               backgroundColor: 'green',
              width:wp("9%"),
              borderRadius:30,
                 height:hp("5%"),
                 alignItems:"center",
                 justifyContent:"center",
                position: 'absolute',
                zIndex: 1000,
                right: 55,
                top: 6,
              },
});