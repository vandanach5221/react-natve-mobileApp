import React from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, BackHandler, ActivityIndicator,
         Dimensions,Picker, } from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
  listenOrientationChange as loc,
  removeOrientationListener as rol
} from 'react-native-responsive-screen';
import Icon from 'react-native-vector-icons/Ionicons';
import axios from 'axios';
let {width, height} = Dimensions.get('window');
import Dialog, { DialogFooter, DialogButton, DialogTitle, SlideAnimation, DialogContent } from 'react-native-popup-dialog';


export default class Task extends React.Component {
constructor(props){
super(props);
this.state = {
    scheduleList:[],
    visible:false,
    loading: true,
    setStatus:'',
};
}
componentDidMount()
{
this.scheduleList();
}
 updateStatus = () => {
        alert("updated")
 }

 changePassword(){
       Actions.changepassword();
  }

//removeEverything = async () => {
//   try {
//     await AsyncStorage.clear()
//      this.refs.toast.show(<View><Text style = {{color: 'green',fontSize: 18,}}>Logged Out Successfully!</Text></View>);
//   } catch (e) {
//     this.refs.toast.show('Failed to clear the async storage.')
//   }
// }

  logout = () => {
//     this.removeEverything();
     Actions.login();
   };

  scheduleList = () => {
         var querystring = require('query-string');
           const apiBaseUrl ='http://sms.kmsgtech.com:8086/sta/tasks/list?teacherId=1&schoolId=1';
           axios.post(apiBaseUrl,
           ).then((response)=>{
                if(response.data.SvcStatus == 'Success'){
                        this.setState({
                          scheduleList: response.data.lstTasks,
                        });
                    //    alert(this.state.scheduleList);
                        this.setState({loading: false});

                         response.data.lstTasks = response.data.lstTasks.map(item =>
                             {
                                item.isSelect = false;
                                item.selectedClass = styles.list;
                                return item;
                                        });

                       }
                       else{
                        alert(response.data.SvcMsg);
                        this.setState({loading: false});
                       }
                       }).catch((error)=>{
                         alert('Service failed: '+error);
                         this.setState({loading: false});
                       });
  };

  confirmTask = () => {
         var querystring = require('query-string');
           const apiBaseUrl ='http://sms.kmsgtech.com:8086/sta/tasks/complete?teacherId=1&schoolId=1&taskId=1';
           axios.post(apiBaseUrl,
           ).then((response)=>{
                if(response.data.SvcStatus == 'Success'){
                alert("Task Completed");
                this.scheduleList();
                    //    alert(this.state.scheduleList);
                   //     this.setState({loading: false});

                       }
                       else{
                        alert(response.data.SvcMsg);
                        this.setState({loading: false});
                       }
                       }).catch((error)=>{
                         alert('Service failed: '+error);
                         this.setState({loading: false});
                       });
  };

//  scheduleList = () => {
//                         this.state.scheduleList = this.state.scheduleList.map(item =>
//                             {
//                                item.isSelect = false;
//                                return item;
//                                        });
//                            };

  selectItem = data => {
//alert(data.item.task);
this.setState({ visible: true })
this.setState({setStatus:data.item.status})
  };


  renderItem = data =>
       <TouchableOpacity style={styles.listView}

          >
            <View>
                <Text style={styles.taskText}>{data.item.task}</Text>
                <Text>{data.item.wing}</Text>
            </View>
            <View>
                <Text style={styles.dueDateText}>{'Due Date:' + data.item.dueDate}</Text>
                 <View style={{flexDirection:"row",paddingTop:5}}>
                 {(data.item.status == "COMPLETED") ?
                <Icon color="#8B0000" style={{color:"green",marginLeft:10,}} size={30} name={'ios-checkmark-circle'}/> :
                <TouchableOpacity
                            style={{width:wp("12%"),height:hp("4%"),backgroundColor:"#AFEEEE",borderRadius:5,
                                      borderWidth:1,alignItems:"center",justifyContent:"center"}}
                                      onPress={() => this.selectItem(data)}>
                <Text style={{fontSize:14,color:"black",fontWeight:"bold"}}>Edit</Text>
                            </TouchableOpacity>
                }
                </View>
            </View>
         </TouchableOpacity>

render()
{
 if (this.state.loading)
    {
      return (
      <View style={styles.loader}>
       <ActivityIndicator size="large" color="green" />
       <Text>Please Wait...</Text>
      </View>
      );
      }
return(
<View style={{flex:1,marginTop:hp("4%")}}>
   <View style={{height:height/15,backgroundColor:"#FFE4C4"}}>
    </View>
       <TouchableOpacity style = {styles.logoutButton} onPress = {this.logout}>
          <Icon color="white" size={30} name={'ios-power'}/>
       </TouchableOpacity>
       <TouchableOpacity style = {styles.forgotButton} onPress = {this.changePassword}>
          <Icon color="white" size={30} name={'ios-lock'}/>
       </TouchableOpacity>
    <FlatList
       data={this.state.scheduleList}
       renderItem={item => this.renderItem(item)}
     />
             <Dialog
                      width={width/1.5}
                      height={height/4}
                      visible={this.state.visible}
                      dialogTitle={<DialogTitle title= {this.state.popUpTime} />}
                      footer={
                        <DialogFooter>
                          <DialogButton
                            text="CANCEL"
                            onPress={() => {
                              this.setState({visible:false});
                              }}
                          />
                          <DialogButton
                            text="OK"
                            onPress={() => {
                            this.setState({visible:false});
                            this.confirmTask();

                              }}
                          />
                        </DialogFooter>
                       }
                      onTouchOutside={() => {
                        this.setState({visible:false});
                        }}
                      dialogAnimation={new SlideAnimation({
                        slideFrom: 'bottom',
                      })}
                    >
                      <DialogContent>
                        {
                        <View style = {{flexDirection:"row"}}>
                          <View style={{flexDirection:"column",width:width/5}}>
                              <Text style={{marginBottom:6}}>Task Status</Text>
                              <Text>Chg Status</Text>
                          </View>
                          <View style={{flexDirection:"column",width:width/3}}>
                              <Text style={{marginBottom:6}}>{this.state.setStatus}</Text>

                          </View>
                        </View>
                        }
                      </DialogContent>
                     </Dialog>
</View>
)
}
}

const styles = StyleSheet.create({
    list: {
        width:width,
        height:height/8,
        alignSelf:"center",
        borderWidth: 0.4,
        backgroundColor: 'white',
        borderTopColor: '#000000',
        },
    listView:{
        flexDirection:"row",
        padding:"2%",
        justifyContent:"space-between"
        },
    taskText:{
        height:height/15,
        fontSize:18,
        fontWeight:"bold"
        },
    dueDateText:{
        height:height/20,
        fontSize:15,
        fontWeight:"bold"
        },
     logoutButton: {
                  backgroundColor: 'red',
                  position: 'absolute',
                  borderRadius:30,
                  zIndex: 1000,
                  width:wp("9%"),
                  height:hp("5%"),
                  alignItems:"center",
                  justifyContent:"center",
                  right: 8,
                  top: 6,
                  },
      forgotButton: {
       backgroundColor: 'green',
      width:wp("9%"),
      borderRadius:30,
         height:hp("5%"),
         alignItems:"center",
         justifyContent:"center",
        position: 'absolute',
        zIndex: 1000,
        right: 55,
        top: 6,
      },
          loader: {
              flex: 1,
              justifyContent: "center",
              alignItems: "center",
              backgroundColor: "#fff"
          },
});