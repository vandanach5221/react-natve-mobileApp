import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Button,
  StatusBar
} from 'react-native';
import { Router, Scene } from 'react-native-router-flux';
import Schedule from './schedule';
import Task from './tasks';
import Attendance from './attendance';
import Example from './example';
import Splash from './splash';
import Login from './login';
import ChangePassword from './changepassword';
import Icon from 'react-native-vector-icons/Ionicons';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

const App = () => {

  return (

  <View style={styles.MainContainer}>
<StatusBar
barStyle = "light-content"
hidden = {false}
backgroundColor = "orange"
translucent = {true}
networkActivityIndicatorVisible = {true}
/>
    <Router navigationBarStyle={styles.navBarHead}   titleStyle={styles.titleStyle}>
     <Scene key="root">
     <Scene key="example" component={Example} hideNavBar={true} />
     <Scene key="splash" initial component={Splash} hideNavBar={true} />
     <Scene key="login" component={Login} hideNavBar={true} />
     <Scene key="changepassword" component={ChangePassword} />
     <Scene key='tabBar' tabs={true} hideNavBar tabBarPosition="bottom" >
         <Scene key="schedule" hideNavBar component={Schedule} title="Schedule" icon={() => { return <AppLogo2 />; }} />
         <Scene key="tasks" hideNavBar component={Task} title="Task" icon={() => { return <AppLogo1 />; }} />
         <Scene key="attendance" hideNavBar component={Attendance} titleStyle={styles.navTitle}
         title="Attendance" icon={() => { return <AppLogo />; }} />
     </Scene>
    </Scene>
    </Router>
        </View>
  );
}

const AppLogo1 = () => {
  return (
    <View style={{ alignItems: 'center', marginTop: 5,}}>
            <Icon color="#4B0082" size={25} name={'ios-list'}/>
    </View>
  );
};

const AppLogo = () => {
  return (
    <View style={{ alignItems: 'center', marginTop: 5 }}>
         <Icon color="#8B0000" size={30} name={'md-checkbox-outline'}/>
    </View>
  );
};

const AppLogo2 = () => {
  return (
    <View style={{ alignItems: 'center', marginTop: 5 }}>
         <Icon color="#2F4F4F" size={25} name={'ios-timer'}/>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  navBarHead:{
  backgroundColor: '#87CEFA',
  marginTop:24,
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  MainContainer :{
  justifyContent: 'center',
  flex:1,
  marginTop: (Platform.OS == 'ios') ? 20 : 0
  },
  titleStyle: {
      fontSize: 18,
      textAlign:"left",
      position:'relative',
      left: wp("-5%"),
  },
  navTitle: {
      color: 'white',
    },
});

export default App;